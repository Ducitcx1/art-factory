Data Pipelines CLI
-----

**DBT Airflow Factory** works best in tandem with `data-pipelines-cli <https://pypi.org/project/data-pipelines-cli/>`_
tool. **dp** not only prepares directory for the library to digest, but also automates Docker image building and pushes
generated directory to the cloud storage of your choice.
